package com.whitenoise.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.os.*
import kotlin.math.*
import kotlin.random.Random

class NoiseService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var endAt = 0L
    }

    private val h = Handler(Looper.getMainLooper())
    private var wl: PowerManager.WakeLock? = null
    @Volatile private var quit = false
    @Volatile private var th: Thread? = null
    private val tick = Runnable { end() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Cfg.load(this)
        fg()
        when (i?.action) {
            "STOP" -> end()
            "TIMER" -> arm()
            "PLAY" -> begin()
        }
        if (!running && th == null) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        return START_NOT_STICKY
    }

    private fun fg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("n", "백색소음", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, NoiseService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "n").setSmallIcon(R.drawable.ic_fg).setContentTitle("백색소음 재생 중")
            .setContentIntent(open).setOngoing(true).addAction(0, "정지", stop).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)
    }

    private fun begin() {
        if (running) return
        running = true; quit = false
        wl = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wn:play").apply { setReferenceCounted(false); acquire() }
        th = Thread { engine() }.also { it.start() }
        arm()
        NoiseWidget.refresh(this)
    }

    private fun end() {
        if (!running) return
        running = false; quit = true; endAt = 0
        h.removeCallbacks(tick)
        try { wl?.release() } catch (_: Exception) {}
        NoiseWidget.refresh(this)
    }

    private fun arm() {
        h.removeCallbacks(tick)
        val m = Cfg.timer
        if (m > 0 && running) { endAt = System.currentTimeMillis() + m * 60000L; h.postDelayed(tick, m * 60000L) } else endAt = 0
        NoiseWidget.refresh(this)
    }

    override fun onDestroy() { try { wl?.release() } catch (_: Exception) {}; super.onDestroy() }

    private class Ch {
        var b0 = 0.0; var b1 = 0.0; var b2 = 0.0; var b3 = 0.0; var b4 = 0.0; var b5 = 0.0; var b6 = 0.0
        var last = 0.0; var x1 = 0.0; var x2 = 0.0; var y1 = 0.0; var y2 = 0.0
        fun next(kind: Int, k: DoubleArray): Double {
            val w = Random.nextDouble() * 2 - 1
            val v = when (kind) {
                0 -> w * .5
                1 -> {
                    b0 = .99886 * b0 + w * .0555179; b1 = .99332 * b1 + w * .0750759; b2 = .969 * b2 + w * .153852
                    b3 = .8665 * b3 + w * .3104856; b4 = .55 * b4 + w * .5329522; b5 = -.7616 * b5 - w * .016898
                    val o = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * .5362) * .11; b6 = w * .115926; o
                }
                else -> { last = (last + .02 * w) / 1.02; last * 3.5 }
            }
            val y = k[0] * v + k[1] * x1 + k[2] * x2 - k[3] * y1 - k[4] * y2
            x2 = x1; x1 = v; y2 = y1; y1 = y
            return y
        }
    }

    private fun lowpass(f: Double, sr: Int, k: DoubleArray) {
        val w0 = 2 * PI * f / sr; val c = cos(w0); val al = sin(w0) / (2 * 0.7071); val a0 = 1 + al
        k[0] = (1 - c) / 2 / a0; k[1] = (1 - c) / a0; k[2] = k[0]; k[3] = -2 * c / a0; k[4] = (1 - al) / a0
    }

    private fun track(sr: Int): AudioTrack {
        val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
            .setBufferSizeInBytes(max(min, 16384)).setTransferMode(AudioTrack.MODE_STREAM).build()
    }

    private fun engine() {
        var sr = 96000   // 44kHz 음색까지 표현하려면 샘플레이트 90kHz 이상 필요
        var at: AudioTrack? = null
        for (r in intArrayOf(96000, 48000)) { try { at = track(r); sr = r; break } catch (_: Exception) {} }
        val t = at
        if (t == null) { h.post { end(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }; return }
        val n = 2048; val buf = ShortArray(n * 2)
        val ch = arrayOf(Ch(), Ch()); val k = DoubleArray(5)
        var g = 0.0; var lastF = -1
        t.play()
        while (true) {
            val kind = Cfg.type; val f = Cfg.freq
            if (f != lastF) { lowpass(f.toDouble().coerceIn(20.0, sr * 0.49), sr, k); lastF = f }
            val target = if (quit) 0.0 else (Cfg.vol / 100.0).let { it * it }
            for (i in 0 until n) {
                g += (target - g) * 0.00004
                for (c in 0..1) buf[i * 2 + c] = ((ch[c].next(kind, k) * g).coerceIn(-1.0, 1.0) * 32767).toInt().toShort()
            }
            t.write(buf, 0, buf.size)
            if (quit && g < 0.005) break
        }
        try { t.stop() } catch (_: Exception) {}
        t.release()
        if (th === Thread.currentThread()) th = null
        h.post { if (!running && th == null) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() } }
    }
}
