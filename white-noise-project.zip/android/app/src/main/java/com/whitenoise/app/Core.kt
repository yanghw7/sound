package com.whitenoise.app

import android.content.Context
import android.content.Intent

object Cfg {
    @Volatile var type = 0       // 0 화이트, 1 핑크, 2 브라운
    @Volatile var vol = 50
    @Volatile var freq = 20000   // 0~44000 Hz
    @Volatile var timer = 0      // 분
    private var loaded = false
    @Synchronized fun load(c: Context) {
        if (loaded) return
        val p = c.applicationContext.getSharedPreferences("n", 0)
        type = p.getInt("type", 0); vol = p.getInt("vol", 50); freq = p.getInt("freq", 20000); timer = p.getInt("timer", 0)
        loaded = true
    }
    fun save(c: Context) {
        c.applicationContext.getSharedPreferences("n", 0).edit()
            .putInt("type", type).putInt("vol", vol).putInt("freq", freq).putInt("timer", timer).apply()
    }
}

object Controller {
    fun apply(c0: Context, a0: String, x: Int = 0) {
        val c = c0.applicationContext
        Cfg.load(c)
        var a = a0
        if (a == "TOGGLE") a = if (NoiseService.running) "STOP" else "PLAY"
        when (a) {
            "TYPE" -> Cfg.type = x.coerceIn(0, 2)
            "VOL" -> Cfg.vol = x.coerceIn(0, 100)
            "FREQ" -> Cfg.freq = x.coerceIn(0, 44000)
            "TIMER" -> Cfg.timer = x.coerceIn(0, 1440)
        }
        Cfg.save(c)
        val i = Intent(c, NoiseService::class.java).setAction(a)
        try {
            when (a) {
                "PLAY" -> c.startForegroundService(i)
                "STOP", "TIMER" -> if (NoiseService.running) c.startService(i)
            }
        } catch (_: Exception) {}
        NoiseWidget.refresh(c)
    }
}
