package com.whitenoise.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var w: WebView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Cfg.load(this)
        w = WebView(this)
        setContentView(w)
        w.setBackgroundColor(0xFF0F161E.toInt())
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(), "NoiseBridge")
        w.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        // 배터리 최적화 제외 요청 (최초 1회)
        val sp = getSharedPreferences("n", 0)
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !sp.getBoolean("asked", false)) {
            sp.edit().putBoolean("asked", true).apply()
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
        }
    }

    @Deprecated("back")
    override fun onBackPressed() { moveTaskToBack(true) }   // 앱을 닫지 않고 백그라운드로

    inner class Bridge {
        @JavascriptInterface fun cmd(a: String, x: Int) { Controller.apply(this@MainActivity, a, x) }
        @JavascriptInterface fun state(): String = JSONObject()
            .put("playing", NoiseService.running)
            .put("type", listOf("white", "pink", "brown")[Cfg.type])
            .put("vol", Cfg.vol).put("freq", Cfg.freq).put("timer", Cfg.timer)
            .put("endAt", NoiseService.endAt).toString()
    }
}
