package com.whitenoise.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

class NoiseWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { refresh(c) }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == ACT) {
            val u = i.data ?: return
            Controller.apply(c, u.host ?: return, u.lastPathSegment?.toIntOrNull() ?: 0)
        }
    }

    companion object {
        const val ACT = "com.whitenoise.app.CMD"
        private val names = listOf("화이트", "핑크", "브라운")

        private fun bind(c: Context, v: RemoteViews, id: Int, a: String, x: Int, on: Boolean) {
            v.setInt(id, "setBackgroundResource", if (on) R.drawable.bg_btn_on else R.drawable.bg_btn)
            val pi = PendingIntent.getBroadcast(
                c, "$a$x".hashCode(),
                Intent(c, NoiseWidget::class.java).setAction(ACT).setData(Uri.parse("wn://$a/$x")),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(id, pi)
        }

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, NoiseWidget::class.java))
            if (ids.isEmpty()) return
            Cfg.load(c)
            val v = RemoteViews(c.packageName, R.layout.widget)
            val on = NoiseService.running
            v.setTextViewText(R.id.w_play, if (on) "■  정지" else "▶  재생")
            bind(c, v, R.id.w_play, "TOGGLE", 0, on)
            val tm = if (Cfg.timer == 0) "끔" else if (Cfg.timer < 60) "${Cfg.timer}분" else if (Cfg.timer % 60 == 0) "${Cfg.timer / 60}시간" else "${Cfg.timer / 60}시간 ${Cfg.timer % 60}분"
            v.setTextViewText(R.id.w_status, "${names[Cfg.type]} · 타이머 $tm" + if (on) " · 재생 중" else "")
            for (t in 0..2) bind(c, v, intArrayOf(R.id.w_t0, R.id.w_t1, R.id.w_t2)[t], "TYPE", t, Cfg.type == t)
            v.setTextViewText(R.id.w_vol, "볼륨 ${Cfg.vol}%")
            bind(c, v, R.id.w_vd, "VOL", (Cfg.vol - 10).coerceAtLeast(0), false)
            bind(c, v, R.id.w_vu, "VOL", (Cfg.vol + 10).coerceAtMost(100), false)
            v.setTextViewText(R.id.w_tl, "타이머 $tm")
            bind(c, v, R.id.w_td, "TIMER", (Cfg.timer - 10).coerceAtLeast(0), false)
            bind(c, v, R.id.w_tu, "TIMER", (Cfg.timer + 10).coerceAtMost(1440), false)
            val tms = intArrayOf(0, 30, 60, 120, 240)
            val tid = intArrayOf(R.id.w_m0, R.id.w_m1, R.id.w_m2, R.id.w_m3, R.id.w_m4)
            for (j in tms.indices) bind(c, v, tid[j], "TIMER", tms[j], Cfg.timer == tms[j])
            m.updateAppWidget(ids, v)
        }
    }
}
